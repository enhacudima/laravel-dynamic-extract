<?php

namespace Enhacudima\DynamicExtract\Classes;

class DynamicExtract
{
    //
}
